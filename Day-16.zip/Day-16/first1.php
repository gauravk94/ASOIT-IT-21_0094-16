<!DOCTYPE html>
<html>

<body>

    <?php
echo "My php programmmmm!";
?>

</body>

</html>